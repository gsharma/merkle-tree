/*
 * Copyright (C) LiveFoundry Inc 2013
 *
 * All rights reserved. Any use, copying, modification, distribution and selling
 * of this software and it's documentation for any purposes without authors' written
 * permission is hereby prohibited.
 */

#import <Foundation/Foundation.h>

#if TARGET_OS_IPHONE
#import <AVFoundation/AVFoundation.h>
#else
#import <AppKit/NSImage.h>
#endif

/**
 * Defines the name of the video frame size changed event
 * `onVideoFrameSizeChanged`
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventVideoFrameSizeChanged = @"onVideoFrameSizeChanged";

/**
 * Defines the name of the connection lost event
 * `onConnectionLost`
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventConnectionLost = @"onConnectionLost";

/**
 * Defines the name of the session reconnected event
 * `onSessionReconnected`
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventSessionReconnected = @"onSessionReconnected";

/**
 * Defines the name of the device list changed event
 * `onDeviceListChanged`
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventDeviceListChanged = @"onDeviceListChanged";

/**
 * Defines the name of the media connection type changed event
 * `onMediaConnTypeChanged`
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventMediaConnTypeChanged = @"onMediaConnTypeChanged";

/**
 * Defines the name of the media issue event
 * `onMediaIssue`
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventMediaIssue = @"onMediaIssue";

/**
 * Defines the name of the media interrupt event
 * `onMediaInterrupt`
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventMediaInterrupt = @"onMediaInterrupt";

/**
 * Defines the name of the media stats event
 * `onMediaStats`
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventMediaStats = @"onMediaStats";

/**
 * Defines the name of the media stream event
 * `onMediaStreamEvent`
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventMediaStreamEvent = @"onMediaStreamEvent";

/**
 * Defines the name of the message event
 * `onMessage`
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventMessage = @"onMessage";

/**
 * Defines the name of the user event
 * `onUserEvent`
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventUserEvent = @"onUserEvent";

/**
 * Defines the name of the mic activity event
 * `onMicActivity`
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventMicActivity = @"onMicActivity";

/**
 * Defines the name of the speech activity event
 * `onSpeechActivity`
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventSpeechActivity = @"onSpeechActivity";

/**
 * Defines the name of the media stream failure event
 * `onMediaStreamFailure`
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventMediaStreamFailure = @"onMediaStreamFailure";

/**
 * Defines the name of the dictionary key used when sending the event
 * notifications via NSNotificationCenter
 *
 * @since 3.0.1.70
 */
static NSString* const kALEventDictionaryKey = @"event";

/**
 * Platform initialization options.
 */
@interface ALInitOptions : NSObject

/**
 * Id of an application using the SDK.
 *
 * @since 2.0.3.10
 */
@property (nonatomic, copy) NSNumber* applicationId;

/**
 * API key part of the credentials.
 *
 * Once the property is defined, the application does not have to calculate
 * authentication signatures as it will be done by the
 * `[ALService connect:responder:]` method. Please note that for security
 * reasons it is adviced not to pass the api credentials to the client side and
 * perform all the authentication on the application's server side components.
 *
 * @since 2.0.3.10
 */
@property (nonatomic, copy) NSString* apiKey;


/**
 * URL for the service resolving Streamer endpoint.
 *
 * @since 2.0.3.0
 */
@property (nonatomic,copy) NSString* streamerEndpointResolver;

/**
 * Flag to enable/disable camera follows device orientation.
 *
 * ### Availability
 *
 * iOS: YES
 * OSX: NO
 *
 * ### Default value
 *
 * Default: YES
*
 * @since 2.0.2.0
 */
@property (nonatomic, assign) BOOL cameraFollowsOrientation;


/**
 * Flag to enable/disable screen follows device orientation.
 *
 * ### Availability
 *
 * iOS: YES
 * OSX: NO
 *
 * ### Default value
 *
 * Default: YES
 *
 * @since 3.0.1.25
 */
@property (nonatomic, assign) BOOL screenFollowsOrientation;

/**
 * Flag to enable/disable external video input. When the external video input is enabled, the AddLive SDK
 * will not process any requests related to video devices configuration 
 * (e.g. setVideoCaptureDevice, getVideoCaptureDevice)
 *
 * ### Availability
 *
 * iOS: YES
 * OSX: NO
 *
 * ### Default value
 *
 * Default: NO
 *
 * @since 3.0.0.27
 */
@property (nonatomic, assign) BOOL externalVideoInput;



/**
 * OS filesystem path to the AddLive resources directory.
 *
 * ### Availability
 *
 * iOS: NO
 * OSX: YES
 */
@property (nonatomic, copy) NSString* resourcesPath;

/**
 * Allowing one to skip the devices initialisation phase. By defualt, the platform will try to setup the
 * devices to sane default values. With this flag set to NO, the devices init phase is aborted.
 * It's especially useful for applications not using camera device on OSX, as this will not make the camera
 * active when the user does not expect it. Or in a case when it is not expected by the user to see
 * camera as active during the platform initialisation.
 *
 * ### Availability
 *
 * iOS: YES
 * OSX: YES
 *
 * ### Default value
 *
 * Default: YES
 *
 * @since 3.0.1.9
 */
@property (nonatomic, assign) BOOL initDevices;


/**
 * Property that enables logging of all application <> SDK interactions using NSLog.
 *
 * ### Availability
 *
 * iOS: YES
 * OSX: YES
 *
 * ### Default value
 *
 * Default: NO
 * @since 3.0.1.9
 */
@property (nonatomic, assign) BOOL logInteractions;


/**
 * Property that when set to YES requests the SDK to preserve the configuration of the AVAudioSession.
 *
 * The AddLive SDK by default will update the configuration of the `AVAudioSession` to category 
 * `AVAudioSessionCategoryPlayAndRecord` and mode `AVAudioSessionModeVideoChat` (iOS 7 and above) or 
 * `AVAudioSessionModeVoiceChat` (iOS 6). 
 *
 * ### Availability
 *
 * iOS: YES
 * OSX: NO
 *
 * ### Default value
 *
 * Default: NO
 * @since 3.0.1.9
 */
@property (nonatomic, assign) BOOL preserveAVAudioSessionConfig;

/**
 * Property allowing application to control whether the AddLive should output logs into the device's console.
 *
 *
 * ### Availability
 *
 * iOS: YES
 * OSX: NO
 *
 * ### Default value
 *
 * Default: YES
 * @since 3.0.1.29
 */
@property (nonatomic, assign) BOOL consoleLoggingEnabled;

/**
 * Property allowing to receive the event notifications via NSNotificationCenter.
 * nil means that none notification center instance will we be used.
 *
 * Please refer to the iOS Tutorial 5.2 to see the functionality
 *
 * ### Availability
 *
 * iOS: YES
 * OSX: YES
 *
 * ### Default value
 *
 * Default: nil
 * @since 3.0.1.70
 */
@property (nonatomic, assign) NSNotificationCenter* notificationCenter;


/**
 * URL for runtime configuration.
 *
 * #### Deprecated
 * Starting from v2.0.3.X please use the direct configuration instead through
 * other properties of the `ALInitOptions` interface.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* configUrl;


@end // @interface ALInitOptions

/**
 * Describes an error. Used by the SDK to indicate any processing
 * error. Contains a code and a message. This is the default result of every
 * call to `ALService` methods.
 */
@interface ALError : NSObject

/** @name Properties */

/**
 * Code of an error. Allows developer to explicitly identify source of
 * a problem. See `ALErrorCodes` for more information.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) int err_code;

/**
 * Additional, human-readable error message.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* err_message;

// To be used by the SDK
- (id) initWithCode:(int) code withMessage:(NSString*) message;

+ (id) errorWithCode:(int) code withMessage:(NSString*) message;

@end // @interface ALError

// =============================================================================

/**
 * Describes a device, used in response from
 * `[ALService getVideoCaptureDeviceNames:]`.
 * 
 * @since 1.0.0.0
 */
@interface ALDevice : NSObject

/** @name Properties */

/**
 * Human readable label of a device.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* label;

/**
 * Identifier to be used when selecting a device.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* id;

@end // @interface ALDevice

// =============================================================================

// =============================================================================

/**
 * Describes video stream parameters, required in `ALConnectionDescriptor`.
 *
 * Capture parameters for the video device are hardcoded to VGA (640x480,
 * landscape) resolution and 15 frames per second inside the SDK. The values
 * set in this descriptor are guiding the video encoder and the adaptative
 * rate control algorithm.
 *
 * The camera orientation follows the device orientation. This means when the
 * device is portrait the output of the camera will be 480x640 - in landscape it
 * is 640x480.
 *
 * The video stream parameters maxWidth and maxHeight are always for portrait.
 * The SDK takes care of the orientation automatically by swapping width and
 * height.
 *
 * @since 1.0.0.0
 */
@interface ALVideoStreamDescriptor : NSObject

/** @name Properties */

/**
 * Max width of the video stream (portrait).
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) unsigned int maxWidth;

/**
 * Max height of the video stream (portrait).
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) unsigned int maxHeight;

/**
 * Max bit rate to be used by the stream.
 *
 * #### Deprecated ####
 * Since 2.0.3.0 this property is not respected.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) unsigned int maxBitRate;

/**
 * Max amount of frames per second to be encoded.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) unsigned int maxFps;

/**
 * Flag defining whether the client wishes to publish this layer.
 *
 * #### Deprecated ####
 * Since 2.0.3.0 this property is not respected.
 */
@property (nonatomic,assign) bool publish;

/**
  * Flag defining whether the client wishes to receive this layer.
  *
  * #### Deprecated ####
  * Since 2.0.3.0 this property is not respected.
  */
@property (nonatomic,assign) bool receive;

/**
  * Flag defining whether the adaptation algotirhms should be enabled or not.
  *
  * @since 2.0.3.0
  */
@property (nonatomic,assign) bool useAdaptation;

- (NSDictionary*) toDict;

@end // @interface ALVideoStreamDescriptor

// =============================================================================

/**
 * Authentication details required in `ALConnectionDescripto`r to connect to the
 * AddLive Streamer.
 *
 * @since 1.0.0.0
 */
@interface ALAuthDetails : NSObject

/** @name Properties */

/**
 * ID of the user who wants to establish the connection.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) long long userId;

/**
 * UTC timestamp defining an expiry timestamp of this authentication token.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) long long expires;

/**
 * Salt used when calculating this authentication token.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* salt;

/**
 * Signature calculated from the auth fields and the secret key.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* signature;

/**
 * Generates the authentication details using all properties provided.
 *
 * @param appId   An integer identifying the application.
 * @param scopeId The scope the token should be generated for.
 * @param userId  ID of the user the token should be generated for.
 * @param salt    Salt used when calculating the token.
 * @param expires UTC timestamp defining an expiry timestamp of the token.
 * @param key     A secret key used for signing the token.
 * @since 1.0.0.0
 */
+ (NSString*) signDetails:(NSNumber*) appId
      scopeId:(NSString*) scopeId
       userId:(long long) userId
         salt:(NSString*) salt
      expires:(long long) expires
    secretKey:(NSString*) key;

- (void) signDetails:(NSNumber*) appId
             scopeId:(NSString*) scopeId
                 key:(NSString*) key;

- (NSDictionary*) toDict;

@end // @interface ALAuthDetails

// =============================================================================

/**
 * Describes parameters to connect to the AddLive media streamer. Used in
 * `[ALService connect:responder:]`.
 *
 * @since 1.0.0.0
 */
@interface ALConnectionDescriptor : NSObject

/** @name Properties */

/**
 * Defines a complete URL of a scope to connect to.
 *
 * In form:
 *
 *       __IP\_OR\_DOMAIN\_NAME__ + ':' + __PORT__ + '/' + __SCOPE\_ID__
 *
 * __SCOPE\_ID__, defines a media scope within the streamer. All users connected
 * to a particular scope exchange media streams published within the scope.
 * If given user publishes a stream (audio, video, screen or any combination
 * of them) all users connected to this scope will be receiving this stream.
 * Additionally, the SCOPE_ID param is used in connection management
 * API - to specify the scope on which given action should be performed.
 * The url attribute is optional, and needs to be specified only if
 * scopeId wasn't defined.  When defined, takes precedense over the scopeId.
 *
 * Default value: `__@""__`
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* url;

/**
 * ID of scope to connect to.
 *
 * If the connection descriptor has the scopeId property defined, the SDK will
 * resolve which streamer should be used to conduct the session so:
 *
 * - all users trying to connect to the same scope will use the same streamer,
 * - the best streamer is used from both load balancing and geography point of
 *   view
 *
 * Default value: `__@""__`
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* scopeId;

/**
 * Flag defining whether the video stream should be published after
 * establishing a connection to the AddLive media streamer.
 *
 * Default value: `__YES__`
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) bool autopublishVideo;

/**
 * Flag defining whether the audio stream should be published after
 * establishing a connection to the AddLive media streamer.
 *
 * Default value: `__YES__`
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) bool autopublishAudio;

/**
 * Configuration of the video stream.
 *
 * @see ALVideoStreamDescriptor
 * @since 1.0.0.0
 */
@property (nonatomic,retain) ALVideoStreamDescriptor* videoStream;

/**
 * Authentication details.
 *
 * @see ALAuthDetails
 * @since 1.0.0.0
 */
@property (nonatomic,retain) ALAuthDetails* authDetails;

- (NSDictionary*) toDict;

@end // @interface ALConnectionDescriptor

/**
 * Source for screen sharing session. May be a specific application window or a complete desktop.
 *
 * @see `[ALService getScreenCaptureSources:responder:]`
 * @see `[ALService publish:what:options:responder:]`
 * @since 3.0.0.0
 */
@interface ALScreenCaptureSource : NSObject

/**
 * Id of the source. To be used when publishing the screen sharing feed.
 *
 * @see `[ALService publish:what:options:responder:]`
 * @since 3.0.0.0
 */
@property (nonatomic, copy) NSString* sourceId;


/**
 * Human-readable title the source.
 *
 * @since 3.0.0.0
 */
@property (nonatomic, copy) NSString* title;


#if TARGET_OS_IPHONE
#else

/**
 * Image containing a screen shot of the source.
 *
 * @since 3.0.0.0
 */
@property (nonatomic, copy) NSImage* image;

+ (id) sourceWithDictionary:(NSDictionary*) dict;
- (id) initWithDictionary:(NSDictionary*) dict;

#endif

@end // @interface ALScreenCaptureSource

// =============================================================================

/**
 * Defines how to publish screen sharing media.
 *
 * @since 1.0.0.0
 */
@interface ALMediaPublishOptions : NSObject

/** @name Properties */

/**
 * Id of window to be shared.
 *
 * @since 3.0.0.0
 */
@property (nonatomic,copy) NSString* windowId;

/**
 * Width of the renderer displaying the contents of the screen sharing feed.
 *
 * @since 3.0.0.0
 */
@property (nonatomic,assign) int nativeWidth;

- (NSDictionary*) toDict;

@end // @interface ALMediaPublishOptions

/**
 * Enumerates all possible media issues.
 *
 *
 * @see [ALServiceListener onMediaIssue:]
 */
typedef NS_ENUM(NSUInteger, ALIssueCodes)
{
    /**
     * Indicates an connectivity issue related to high packet loss causing the
     * media feed to froze.
     *
     * @since 2.0.2.0
     */
    kQualityIssueConnectionFrozen = 1,

    /**
     * Indicates a high CPU use on client machine affecting the quality of the
     * streams published.
     *
     * @since 2.0.2.0
     */
    kQualityIssueCpuLoadHigh = 2,

    /**
     * Indicates a problem with CPU over utilisation by an external application.
     * User should consider closing other application(s) utilising CPU heavily.
     * 
     * ### Availability
     *
     * iOS: NO
     * OSX: YES
     * @since 3.0.1.19
     */
    kQualityIssueExternalCpuLoadHigh = 3,
    /**
     * Indicates unspecified networking issues affecting quality of a call. This
     * may be related to a significant loss, jitter or delay.
     *
     * @since 2.0.2.0
     */
    kQualityIssueNetworkProblem = 4,

    /**
     * Indicates that there is not enough bandwidth to transmit the streams
     * requested.
     *
     * @since 2.0.2.0
     */
    kQualityIssueLowBandwidth = 5
    
};

/**
 * Enumeration identifying all the possible error codes.
 *
 * @see ALService
 * @since 1.0.0.0
 */
typedef NS_ENUM(NSInteger, ALErrorCodes)
{

  /** @name General errors. */
  /**
   * Identifies an unknown error.
   *
   * @since 1.0.0.0
   */
  kUnknownError = -1,

  /**
   * Identifies a success result.
   *
   * @since 1.0.0.0
   */
  kNoError = 0,

  /** @name Logic errors. */

  /**
   * Returned when application tries to perform operation on AddLive Service
   * in context of media scope to which service is not currently connected.
   * The common application error that triggers API calls failing with this
   * error code is not to handle the [ALService:connectionLost] notification.
   * In this case, the application still assumes that the connection is active
   * and tries to perform an operations on it, even though the connection is
   * already lost.
   *
   * @since 1.0.0.0
   */
  kLogicInvalidScope = 1001,

  /**
   * Returned when application passed somehow invalid argument to any of the
   * ALService methods.
   *
   * See also
   * @since 1.0.0.0
   */
  kLogicInvalidArgument = 1002,

  /**
   * Indicates a generic failure of the  platform initialisation.
   *
   * @see [ALService initPlatform:responder:]
   * @since 1.0.0.0
   */
  kLogicPlatformInitFailed = 1004,

  /**
   * Indicates that the internal error in service logic occured.
   *
   * @since 1.0.0.0
   */
  kLogicInternal = 1006,

  /**
   * Indicates that the particular ALService operation is not supported on given
   * platform (device).
   *
   * @since 1.0.0.0
   */
  kLogicPlatformUnsupported = 1009,


  /**
   * Generic invalid state error - indicates that the operation cannot be
   * performed in current state of the platform.
   *
   * @since 1.0.0.0
   */
  kLogicInvalidState = 1010,

    
  /**
   * User have not given a consent to use one of the device resources.
   *
   * One of use cases covered here is the microphone access consent, starting
   * from iOS7.
   *
   * @since 2.1.2.0
   */
  kLogicUserConsentNotGiven = 1101,

  /** @name Communication errors. */

  /**
   * Indicates that the service could not resolve the host name or could not
   * connect to host with given id. This error can be returned as a result of
   * [ALService connect:responder:].
   *
   * @since 1.0.0.0
   */
  kCommInvalidHost = 2001,

  /**
   * Indicats that the service managed to connect to the streaming host, but
   * could not connect to the management socket. In most cases it means that the
   * device is not connected to the Internet, or that the connection is really
   * poor. In the latter case, the error message will indicate timeout
   * connecting to the server management socket. Application, when receiving
   * this error code may try to reconnect.
   *
   * @since 1.0.0.0
   */
  kCommInvalidPort = 2002,

  /**
   * Indicates that the streamer rejected the authentication signature given.
   *
   * @since 1.0.0.0
   */
  kCommBadAuth = 2003,

  /**
   * Indicates a failure of a media connectivity. It means, that while trying
   * to connect to the AddLive Streamer, the service managed to establish
   * management connection, but failed to exchange initial media communication
   * handshake. This is most likely due to firewall blocking the media
   * communication.
   *
   * @since 1.0.0.0
   */
  kCommMediaLinkFailure = 2005,

  /**
   * Indicates that the streamer terminated the connection. Used with the
   * [ALServiceListener onConnectionLost:].
   *
   * @since 1.0.0.0
   */
  kCommRemoteEndDied = 2006,

  /**
   * Indicates an internal error in the ALService communication layer.
   *
   * @since 1.0.0.0
   */
  kCommInternal = 2007,


  /**
   * Indicates an internal error in the OpenSSL. May indicate that there is
   * a Deep Packet Inspection proxy involoved configured to use encryption
   * scheme not supported by the platform.
   *
   * @since 1.0.0.0
   */
  kCommOpenSslFailed = 2010,

  /**
   * Indicates that the AddLive Streaming server rejected the connection request
   * because the version of the ALService is not compatibile with it. In most
   * cases it means that the client application is outdated and the user should
   * update the application to use the most recent version of the iOS SDK.
   * During development, it may also indicate that the application uses beta SDK
   * with stable infrastructure.
   *
   * @since 1.0.0.0
   */
  kCommClientVersionNotSupported = 2011,

  /**
   * Indicates a proxy authentication error - the credentials given were
   * rejected by proxy.
   *
   * @since 1.0.0.0
   */
  kCommProxyAuthError = 2012,

  /**
   * Indicates a general failure in proxy connection.
   *
   * @since 1.0.0.0
   */
  kCommProxyConnectionFailed = 2013,


  /**
   * Indicates that another user with the same userId has connected
   * to the scope. Current user should disconnect.
   * @since 3.0.0.0
   */
  kCommNewUserConnectedSameId = 2015,



  /** @name Media errors. */
  /**
   * Indicates that the SDK failed to use configured video capture device. This
   * error may be return as a result of following methods:
   * [ALService setVideoCaptureDevice:responder:],
   * [ALService publish:what:options:responder:],
   * [ALService startLocalVideo:].
   *
   * @since 1.0.0.0
   */
  kMediaInvalidVideoDev = 4001,

  /**
   * Indicates an issue with microphone.
   *
   * @since 1.0.0.0
   */
  kMediaNoAudioInDev = 4002,

  /**
   * Indicates an issue with microphone.
   *
   * @since 1.0.0.0
   */
  kMediaInvalidAudioInDev = 4003,


  /**
   * Indicates an issue with speakers.
   *
   * @since 1.0.0.0
   */
  kMediaInvalidAudioOutDev = 4004,

  /**
   * Indicates a general error with audio engine.
   */
  kMediaInvalidAudioDev = 4005,
  
  /**
   * Indicates that the user closed the window that was currently shared.
   */
  kMediaSharedWindowClosed = 4008
    
};

/**
 * Enumeration listing all possible network quality states.
 *
 * @see [ALService networkTest:authDetails:responder:]
 */
typedef NS_ENUM(NSUInteger, NetworkQuality)
{

    /**
     * Indicates fine network conditions. There should be no quality issues
     * caused by the client networking when sending video feed of a particular
     * configuration.
     *
     * @since 2.0.2.0
     */
    kNetworkFine = 0,

    /**
     * Indicates average network conditions. Although the video streaming
     * functionality will be operational, the user may expect some quality
     * issues.
     *
     * @since 2.0.2.0
     */
    kNetworkAverage,

    /**
     * Indicates bad network conditions. The video streaming may not function
     * at all.
     *
     * @since 2.0.2.0
     */
    kNetworkBad
};

/**
 * Noise suppression modes. To be used with [ALService setNSMode:responder:].
 *
 * @see [ALService setNSMode:responder:]
 */
typedef NS_ENUM(NSUInteger, NSMode)
{

  /**
   * Noise suppression will be disabled.
   */
  kNsDisabled = 0,

  /**
   * User platform defaults configuration.
   *
   * @since 1.0.0.0
   */
  kNsDefault,

  /**
   * Conference mode - especially useful for larger audiences.
   *
   * @since 1.0.0.0
   */
  kNsConference,

  /**
   * Low suppression mode. Useful when there is low background noise for the
   * user as the speech sounds more natural
   *
   * @since 1.0.0.0
   */
  kNsLowSuppression,

  /**
   * Moderate supression mode. Should be treated as a general purpose mode.
   *
   * @since 1.0.0.0
   */
  kNsModerateSuppression,

  /**
   * High supression mode. Useful in situations when there is high background
   * noise.
   *
   * @since 1.0.0.0
   */
  kNsHighSuppression,

  /**
   * Very high supression mode - to be used with really high background noise.
   *
   * @since 1.0.0.0
   */
  kNsVeryHighSuppression,

};

/**
 * Enumeration defining all possible directions of media stats. Used with the
 * ALMediaStats.
 *
 * @see ALMediaStats
 */
typedef NS_ENUM(NSUInteger, ALMediaStatsDirection)
{
  /**
   * Defines uplink statistics direction.
   *
   * @since 1.0.0.0
   */
  kMediaStatsUplink = 0,


  /**
   * Defines downlink statistics direction.
   *
   * @since 1.0.0.0
   */
  kMediaStatsDownlink
};

/**
 * Enumeration defining the audio output devices available on mobiles (front speaker, loud speakerľ
 *
 * @see `[ALService setAudioOutputDevice:responder:]`
 */
@interface ALAudioOutputDevice: NSObject

/**
 * Defines uplink statistics direction.
 *
 * @since 1.0.0.0
 */
+ (NSString*) kLoudSpeaker;


/**
 * Defines downlink statistics direction.
 *
 * @since 1.0.0.0
 */
+ (NSString*) kFrontSpeaker;

@end


/**
 * Enumeration defining the property names to be used with the setProperty/getProperty API.
 *
 * ### Availability
 *
 * iOS: YES
 * OSX: YES
 *
 * @since 3.0.1.25
 * @see `[ALService setProperty:value:responder]`
 * @see `[ALService getProperty:responder]`
 */
@interface ALPropertyNames: NSObject

/**
 * Allows application to enable or disable the audio system as a whole. Use value "0" to disable audio system and "1" to
 * enable it. This API is especially usefull on iOS where the application needs to play sounds during the AddLive 
 * session.
 *
 * @since 3.0.1.25
 */
+ (NSString*) kAudioDeviceEnabled;


@end

/**
 * Enumeration inteface listing all possible media types.
 *
 * ### See Also:
 *
 * - `[ALService publish:what:options:responder:]`
 * - `[ALService unpublish:what:responder:]`
 */
@interface ALMediaType: NSObject

/**
 * Audio media type.
 *
 * @since 2.0.3.10
 */
+ (NSString*) kAudio;

/**
 * Video media type.
 *
 * @since 2.0.3.10
 */
+ (NSString*) kVideo;

/**
 * Screen media type.
 *
 * @since 2.0.3.10
 */
+ (NSString*) kScreen;

@end

/**
 * Enumeration inteface listing all possible media connection types.
 *
 * ### See Also:
 *
 * - `[ALServiceListener onMediaConnTypeChanged:]`
 * - `ALMediaConnTypeChangedEvent`
 */
@interface ALConnectionType: NSObject

/**
 * Represents connection that is not connected.
 *
 * @since 2.0.3.10
 */
+ (NSString*) kNotConnected;

/**
 * Represents an UDP relayed connection. In this connection mode, all the media
 * data are relayed through the AddLive streaming infrastructure.
 *
 * @since 2.0.3.10
 */
+ (NSString*) kUdpRelay;

/**
 * Represents an UDP P2P connection. In this connection mode, all the media
 * data are sent directly between 2 peers connected to the scope.
 *
 * @since 2.0.3.10
 */
+ (NSString*) kUdpP2P;

/**
 * Represents a TCP relayed connection. In this connection mode, all the media
 * data are relayed through the AddLive streaming infrastructure, using the
 * TCP/TLS fallback protocol. Please note that such a connectivity may have an
 * impact on the streaming quality.
 *
 * @since 2.0.3.10
 */
+ (NSString*) kTcpRelay;

@end

/**
 * Contains a video frame for external video input.
 *
 * @since 3.0.0.27
 */

@interface ALVideoFrame : NSObject

#if TARGET_OS_IPHONE
@property (nonatomic,assign) CMSampleBufferRef frameBuffer;
#else
@property (nonatomic,assign) void* frameBuffer;
#endif

@end // ALVideoFrame

/**
 * Object wrapping the platform initialisation result. Provides a feedback 
 * to the application about the media devices available on the device.
 *
 * @since 3.0.1.3
 */
@interface ALInitResult : NSObject

/**
 * Flag definiging whether the camera (video capture device) is available.
 *
 * @since 3.0.1.3
 */
@property (nonatomic, assign) BOOL cameraFunctional;


/**
 * Flag definiging whether the microphone (audio capture device) is available.
 * 
 * Please note that on iOS if the user won't give the application access to the 
 * mirophone device, this flag will be set to NO. In this case, any attempt 
 * to connect, will ignore the autopublishAudio flag and will always use NO 
 * value there.
 *
 * Also every call to `[ALService publish:what:options:responder:]` with media 
 * type kAudio or `[ALService monitorMicActivity:responder:]` will return an error.
 * @since 3.0.1.3
 */
@property (nonatomic, assign) BOOL micFunctional;


/**
 * Flag definiging whether the speakers (audio output device) are available.
 *
 * Please note that as of v3.0.1.3 this property is always true.
 *
 * @since 3.0.1.3
 */
@property (nonatomic, assign) BOOL speakersFunctional;


@end

