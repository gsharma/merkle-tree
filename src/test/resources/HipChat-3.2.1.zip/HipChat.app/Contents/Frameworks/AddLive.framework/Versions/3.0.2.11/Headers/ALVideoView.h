/*
 * Copyright (C) LiveFoundry Inc 2013
 *
 * All rights reserved. Any use, copying, modification, distribution and selling
 * of this software and it's documentation for any purposes without authors'
 * written permission is hereby prohibited.
 */

#import "ALDataTypes.h"
#import "ALService.h"

#import <Foundation/Foundation.h>

#if TARGET_OS_IPHONE
#import <UIKit/UIKit.h>
#else
#import <AppKit/NSView.h>
#endif

typedef NS_ENUM(NSUInteger, ALVideoViewState)
{
    /// Video view state after the allocation
    kCreated = 0,
    
    /// Video view state after setting the service and sink id
    kInitialized,
    
    /// Video view state after calling attach to sink, but before the startRender result
    kStarting,
    
    /// Fully functional state - ALVideoView is rendering sink
    kStarted,
    
    /// Transitional state, where the stopRender was called due to pause request
    kStopping
};


/**
 * Class providing a UI widget for rendering AddLive video sinks.
 *
 * The ALVideoView class provides a complete mechanism for rendering video sinks. It can be
 * added to an application using interface builder and will be came functional, after setting
 * it up with an instance of the `ALService` and an id of sink which this widget should render.
 *
 * After setting the class up, methods `start:` and `stop:` methods can be used to control
 * the rendering.
 *
 * Please note that the class can be reused even after disposal of the original `ALService` 
 * in this case, the rendering must be stopped before calling `[ALService releasePlatform]` and can
 * be restored after setting up with a new service and a new scope id.
 *
 * Also note that it is possible to modify the sink id rendered by this view, using the `setSink:`
 * method. This can be done only while the `ALVideoView` is not actively rendering the existing sink,
 * the rendering needs to be stopped first.
 * 
 * @since 2.1.2.1
 */

#if TARGET_OS_IPHONE
@interface ALVideoView : UIView
#else
@interface ALVideoView : NSView
#endif
/** @name Properties */


/** @name Methods */

/**
 * Sets up this instance of the ALVideoView to work with given service and to render contents of given sink.
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidState`<br/>
 *   If the `ALVideoView` is actively rendering contents of an existing sink.
 *   Stop the rendering using the `stop` method first.
 *
 *
 * @param service `ALService` to be used while rendering.
 * @param sinkId  Id of video sink that should be rendered by this view.
 *
 *     `(void) response:(ALError*) err;`
 */
- (ALError*) setupWithService: (ALService*) service
                withSink: (NSString*) sinkId;

/**
 * Sets up this instance of the ALVideoView to work with given service and to render contents of given sink.
 * Additionally, this method allows an application to specify whether the video feed should be mirrored or not.
 * This is especially useful when rendering local preview video feed.
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidState`<br/>
 *   If the `ALVideoView` is actively rendering contents of an existing sink.
 *   Stop the rendering using the `stop` method first.
 *
 * @param service `ALService` to be used while rendering.
 * @param sinkId  Id of video sink that should be rendered by this view.
 * @param mirror  Boolean flag defining, whether the rendering should be mirrored or not.
 *
 *     `(void) response:(ALError*) err;`
 */
- (ALError*) setupWithService: (ALService*) service
                withSink: (NSString*) sinkId
              withMirror:(BOOL) mirror;


/**
 * Updates the mirror flag of the renderer.
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidState`<br/>
 *   If the `ALVideoView` is actively rendering contents of an existing sink.
 *   Stop the rendering using the `stop` method first.
 *
 * @param mirror  Boolean flag defining, whether the rendering should be mirrored or not.
 *
 *     `(void) response:(ALError*) err;`
 */
- (ALError*) setMirror:(BOOL)mirror;

/**
 * Chagnes the sink that this renderer will be rendering.
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidState`<br/>
 *   If the `ALVideoView` is actively rendering contents of an existing sink.
 *   Stop the rendering using the `stop` method first.
 *
 * @param sinkId  Id of video sink that should be rendered by this view.
 *
 *     `(void) response:(ALError*) err;`
 */
- (ALError*) setSinkId:(NSString*)sinkId;

@property(readonly,nonatomic) NSString* sinkId;

/**
 * Enables extra debug logging through NSLog. NO by default.
 *
 * @since 3.0.1.12
 */
@property(assign, nonatomic) BOOL debugLoggingEnabled;

@property(readonly,nonatomic) ALVideoViewState state;

/**
 * Starts the render.
 *
 * Please note that this method is asynchronous, the rendering is not effectively started until 
 * the responder given here is called.
 *
 * Internaly, this method calls `[ALService renderSink:responder:]` and on the result, it will prepare
 * the OpenGL context required for the draw operations.
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidState`<br/>
 *   If the `ALVideoView` is actively rendering contents of an existing sink.
 *   Stop the rendering using the `stop` method first.
 *
 * @param responder Responder object that will receive a result of call
 *
 *     `(void) response:(ALError*) err;`
 */
- (void) start:(ALResponder*) responder;

/**
 * Stops the render.
 *
 * Please note that this method is asynchronous, the rendering is not effectively stopped until
 * the responder given here is called.
 *
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidState`<br/>
 *   If the `ALVideoView` is actively rendering contents of an existing sink.
 *   Stop the rendering using the `stop` method first.
 *
 * @param responder Responder object that will receive a result of call
 *
 *     `(void) response:(ALError*) err;`
 */
- (void) stop:(ALResponder*) responder;



@end // @interface ALVideoView

