/*
 * Copyright (C) LiveFoundry Inc 2013
 *
 * All rights reserved. Any use, copying, modification, distribution and selling
 * of this software and it's documentation for any purposes without authors' written
 * permission is hereby prohibited.
 */

#import "ALDataTypes.h"

/**
 * Event describing a change of a resolution in a video feed produced
 * by given video sink.
 *
 * This change may be caused by one of following:
 *
 * * Adaptation algorithms decided to increase or reduce the quality of the
 *   video feed on remote end uplink
 * * Remote peer reconfigured the video stream
 * * In case of screen sharing, the window shared was resized
 *
 * ### See Also:
 *
 * [ALServiceListener onVideoFrameSizeChanged:]
 *
 * @see [ALServiceListener onVideoFrameSizeChanged:]
 */
@interface ALVideoFrameSizeChangedEvent : NSObject

/** @name Properties */

/**
 * Id of video sink which resolution has changed.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* sinkId;

/**
 * New height of the video feed.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) int height;

/**
 * New width of the video feed.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) int width;

@end // @interface ALVideoFrameSizeChangedEvent

// =============================================================================

/**
 * Event describing a lost connection.
 *
 * ### See Also:
 *
 * [ALServiceListener onConnectionLost:]
 */
@interface ALConnectionLostEvent : NSObject

/** @name Properties */

/**
 * ID of scope to which the connection was lost.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* scopeId;

/**
 * Error code identifying source of the problem. The most common value here is
 * the `kCommRemoteEndDied`.
 *
 * @see ALErrorCodes
 * @since 1.0.0.0
 */
@property (nonatomic,assign) int errCode;

/**
 * Additional human-readable text message.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* errMessage;


/**
 * Flag defining whether the SDK will attempt to reestablish the connection or not.
 *
 * @since 3.0.0.0
 */
@property (nonatomic, assign) BOOL willReconnect;

@end // @interface ALConnectionLostEvent


/**
 * Event describing a lost connection.
 *
 * ### See Also:
 *
 * [ALServiceListener onConnectionLost:]
 * @since 3.0.0.0
 */
@interface ALSessionReconnectedEvent : NSObject

/** @name Properties */

/**
 * ID of scope to which the connection was lost.
 *
 * @since 3.0.0.0
 */
@property (nonatomic,copy) NSString* scopeId;


@end // @interface ALConnectionLostEvent



// =============================================================================

/**
 * Event class describing change in media status of a remote peer.
 *
 * Event class describing change in media streaming status of a remote peer.
 * This includes: user joining media scope, user leaving media scope, user
 * publishing or stop publishing any of possible media streams.
 *
 * This event is used by two callback methods:
 * `[ALServiceListener onUserEvent:]` and
 * `[ALServiceListener onMediaStreamEvent:]`.  When used in context of the first one,
 * it describes a complete streaming state of a remote peer. Also in this case,
 * the mediaType attribute has `nil` as the event is not related to any
 * particular media.
 *
 * On the other hand, when this event is used by the
 * `[ALServiceListener onMediaStreamEvent:]` it describes only  a change in remote
 * peer's streaming state. In this case, the mediaType defines to which
 * particular media this event is related and then the appropriate
 * audioPublished, videoPublished or screenPublished  attribute defines whether
 * the media was published or unpublished.
 *
 * ### See also:
 *
 * - `[ALServiceListener onUserEvent:]`
 * - `[ALServiceListener onMediaStreamEvent:]`
 * - `[ALService connect:responder:]`
 * - `[ALService publish:what:options:responder:]`
 * - `[ALService unpublish:what:responder:]`
 *
 * @since 1.0.0.0
 */
@interface ALUserStateChangedEvent : NSObject

/** @name Properties */

/**
 * ID of scope to which this event belongs to.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* scopeId;

/**
 * ID of a remote user to which this event belongs to.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) long long userId;

/**
 * Flag defining whether user joined or left the scope. Value is defined
 * only when the event is used with `[ALServiceListener onUserEvent:]` callback.
 *
 * @see [ALServiceListener onUserEvent:]
 * @since 1.0.0.0
 */
@property (nonatomic, assign) bool isConnected;

/**
 * Type of media for which the streaming status has changed. Defined only when
 * the event is used with the `[ALServiceListener onMediaStreamEvent:]`.
 *
 * @see [ALServiceListener onMediaStreamEvent:]
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* mediaType;

/**
 * Flag defining whether the audio stream is published by the user. Used
 * when informing other users about a new user or when status of audio
 * publishing was changed for a user.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) bool audioPublished;

/**
 * Flag defining whether the video stream is published by the user. Used
 * when informing other users about a new user or when status of video
 * publishing was changed for a user.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) bool videoPublished;

/**
 * ID of video sink that can be used to render user's video stream. Defined
 * only if videoPublished is set to true.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* videoSinkId;

/**
 * Flag defining whether the screen sharing stream is published by the user.
 * Used  when informing other users about a new user or when status of screen
 * sharing was changed for a user.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) bool screenPublished;

/**
 * ID of video sink that can be used to render user's screen sharing stream.
 * Defined only if videoPublished is set to true.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* screenSinkId;

@end // @interface ALUserStateChangedEvent


/**
 * Event describing a microphone activity.
 *
 * @since 3.0.0.0
 */
@interface ALMicActivityEvent : NSObject

/**
 * Activity as an integer in range 1-255
 *
 * @since 3.0.0.0
 */
@property (nonatomic, assign) int activity;
@end

// =============================================================================

/**
 * Event describing a change in microphone gain value. This is driven by the 
 * Automatic Gain Control algorithms.
 *
 * @since 3.0.0.0
 */
@interface ALMicGainEvent : NSObject

/**
 * Event describing a change in microphone gain value. This is driven by the
 * Automatic Gain Control algorithms.
 *
 * @since 3.0.0.0
 */
@property (nonatomic, assign) int gain;
@end

// =============================================================================

/**
 * Event describing a change in media devices availability (e.g. new camera
 * available)
 *
 * @since 3.0.0.0
 */
@interface ALDeviceListChangedEvent : NSObject

/**
 * Flag definiing that there was a change in microphones availability.
 *
 * @since 3.0.0.0
 */
@property (nonatomic, assign) bool audioIn;

/**
 * Flag definiing that there was a change in speakers availability.
 *
 * @since 3.0.0.0
 */
@property (nonatomic, assign) bool audioOut;

/**
 * Flag definiing that there was a change in cameras availability.
 *
 * @since 3.0.0.0
 */
@property (nonatomic, assign) bool videoIn;
@end

// =============================================================================


/**
 * Contains media statistics gathered by the SDK, used in the ALMediaStatsEvent.
 *
 * ### See Also:
 *
 * - `[ALServiceListener onMediaStats:]`
 * - `ALMediaStatsEvent`
 *
 */
@interface ALMediaStats : NSObject

/** @name Properties */

/**
 * Stats direction: uplink or downlink.
 *
 * @see ALMediaStatsDirection
 * @since 1.0.0.0
 */
@property (nonatomic, assign) ALMediaStatsDirection direction;

/**
 * Video stats are grouped by layer. There are currently three layers: low video
 * layer, high video layer and screen sharing layer. Only in video stats.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) int layer;

/**
 * Current bitrate of the media.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) float bitRate;

/**
 * Current CPU usage (in percent) of the application using the AddLive SDK. Only
 * in video stats.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) float cpu;

/**
 * Total CPU usage (in percent) of all processes currently running on the
 * device. Only in video stats.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) float totalCpu;

/**
 * Round-trip time (in ms) of the media. Only in audio stats.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) float rtt;

/**
 * Queuing delay: A positive value indicates that packets are getting buffered.
 * A negative value indicates that the network buffers are getting emptied. Only
 * in uplink video stats.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) float queueDelay;

/**
 * Peak signal-to-noise ratio of the encoded video. Only in uplink video stats.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) float psnr;

/**
 * Frames per second encoded by the video encoder. Only in uplink video stats.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) float fps;

/**
 * Number of packets lost since the beginning of streaming.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) int totalLoss;

/**
 * Fractional loss between measurements.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) float loss;

/**
 * An index indicating the quality of the video uplink stream. Only in uplink
 * video stats.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) int quality;

// TODO describe it when it becomes supported.
@property (nonatomic, assign) float jbLength;

/**
 * Average audio jitter (in ms). Only in downlink audio stats.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) float avgJitter;

/**
 * Max. audio jitter (in ms). Only in downlink audio stats.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) float maxJitter;

// TODO describe it when it becomes supported.
@property (nonatomic, assign) float avOffset;

@property (nonatomic, assign) int timestamp;
@property (nonatomic, assign) int processingTime;
@property (nonatomic, assign) int netBps;
@property (nonatomic, assign) int fractionLoss;
@property (nonatomic, assign) int cumulativePacketLoss;
@property (nonatomic, assign) int totalKbps;
@property (nonatomic, assign) int audioDelay;


@end // @interface ALMediaStats

// =============================================================================

/**
 * Service event contains media statistics.
 *
 * ### See Also:
 *
 * - `ALMediaStats`
 * - `[ALServiceListener onMediaStats:]`
 */
@interface ALMediaStatsEvent : NSObject

/** @name Properties */

/**
 * ID of the scope the measurements belong to.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* scopeId;

/**
 * Type of media of the measurements.
 *
 * @see ALMediaType
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* mediaType;

/**
 * Remote user ID of the measurements. An ID equal to -1 indicates local
 * measurements (i.e. uplink).
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) long long remoteUserId;

/**
 * The object containing the measurements.
 *
 * @see ALMediaStats
 * @since 1.0.0.0
 */
@property (nonatomic,retain) ALMediaStats* stats;

@end // @interface ALMediaStatsEvent

// =============================================================================

/**
 * Service event contains a message sent by a remote user.
 *
 * ### See Also
 *
 * - `[ALServiceListener onMessage:]`
 */
@interface ALMessageEvent : NSObject

/** @name Properties */

/**
 * ID of the scope the message was sent in.
 *
 * @since 2.0.2.0
 */
@property (nonatomic,copy) NSString* scopeId;

/**
 * The message body.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSData* data;

/**
 * ID of user who sent the message.
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) long long srcUserId;

@end // @interface ALMessageEvent

// =============================================================================

/**
 * Service event describing a change in the media connection type.
 *
 * ### See Also:
 *
 * - `[ALServiceListener onMediaConnTypeChanged:]`
 */
@interface ALMediaConnTypeChangedEvent : NSObject

/** @name Properties */

/**
 * ID of scope for which the media connection type has changed.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* scopeId;

/**
 * Type of media for which the link type was change.
 *
 * @see ALMediaType
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* mediaType;

/**
 * New type of the media connection.
 *
 * @see ALConnectionType
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* connectionType;

@end // @interface ALMediaConnTypeChangedEvent

// =============================================================================

/**
 * Service event describing an event for media issues.
 *
 * ### See Also:
 *
 * - `[ALServiceListener onMediaIssue:]`
 */
@interface ALMediaIssueEvent : NSObject

/** @name Properties */

/**
 * ID of scope for which the media issue occured.
 *
 * @since 2.0.2.0
 */
@property (nonatomic,copy) NSString* scopeId;

/**
 * Type of media for which the issue occured.
 *
 * @see ALMediaType
 * @since 2.0.2.0
 */
@property (nonatomic,copy) NSString* mediaType;

/**
 * ID of the user the issue occured.
 *
 * @since 2.0.2.0
 */
@property (nonatomic,assign) long long userId;

/**
 * Boolean flag indicating whether the issue was just detected or resolved.
 *
 * @since 2.0.2.0
 */
@property (nonatomic, assign) BOOL isStarted;

/**
 * Media issue code. See ALIssueCodes for all the possible issues.
 *
 * @see ALIssueCodes
 * @since 2.0.2.0
 */
@property (nonatomic,copy) NSNumber* issueType;

/**
 * A description about the media issue.
 *
 * @since 2.0.2.0
 */
@property (nonatomic,copy) NSString* msg;

@end // @interface ALMediaIssueEvent

// =============================================================================

@interface ALEchoEvent : NSObject
@property (nonatomic,copy) NSString* echoValue;
@end

// =============================================================================

/**
 * Service event describing a change of the interruption of a media unit.
 *
 * ### See Also:
 *
 * - `[ALServiceListener onMediaInterrupt:]`
 *
 * #### Deprecated
 * Since 3.0.1.30 The AddLive SDK handles audio interruptions automatically.
 */
@interface ALMediaInterruptEvent : NSObject

/** @name Properties */


/**
 * Type of media for which the interruption occured.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* mediaType;

/**
 * Boolean indicating the interruption (begin = true/end = false)
 *
 * @since 1.0.0.0
 */
@property (nonatomic, assign) BOOL interrupt;

@end // @interface ALMediaInterruptEvent



/**
 * Service event describing a failure in one of the media streams.
 *
 * ### See Also:
 *
 * - `[ALServiceListener onMediaStreamFailure:]`
 *
 * @since 3.0.0.0
 */
@interface ALMediaStreamFailureEvent: NSObject

/**
 * ID of scope for which the media issue occured.
 *
 * @since 3.0.0.0
 */
@property (nonatomic,copy) NSString* scopeId;

/**
 * Type of media for which the issue occured.
 *
 * @see ALMediaType
 * @since 3.0.0.0
 */
@property (nonatomic,copy) NSString* mediaType;

/**
 * Error code identifying source of the problem. The most common value here is
 * the `kCommRemoteEndDied`.
 *
 * @see ALErrorCodes
 * @since 3.0.0.0
 */
@property (nonatomic,assign) int errCode;

/**
 * Additional human-readable text message.
 *
 * @since 3.0.0.0
 */
@property (nonatomic,copy) NSString* errMessage;

@end // @interface ALMediaStreamFailureEvent


/**
 * Class describing speech activity of peer connected to a session.
 *
 * @since 3.0.0.14
 */
@interface ALSpeechActivityInfo:NSObject

/**
 * ID of a remote user whose speech activity this object represents. -1 for local user.
 *
 * @since 3.0.0.14
 */
@property (nonatomic, assign) long long userId;

/**
 * Speech activity of the user. The speech activity level is an normalised integer
 * in range [0..255].
 *
 * @since 3.0.0.14
 */
@property (nonatomic, assign) int activity;


@end // @interface ALSpeechActivityInfo:NSObject


/**
 * Event class describing speech levels within a particualr session. Monitoring of speech activity
 * can be controlled using the `[ALService monitorSpeechActivity:enabled:responder:]` method.
 *
 * The event contains details about speech level of every peer in session (including local user) and
 * also an array of ids of users who are active speakers (using VAD data).
 *
 * @since 3.0.0.14
 */
@interface ALSpeechActivityEvent:NSObject

/**
 * ID of scope for which the event is related.
 *
 * @since 3.0.0.14
 */
@property (nonatomic,copy) NSString* scopeId;

/**
 * Array of speech activity within scope. The array contains instances of `ALSpeechActivityInfo` class.
 *
 * @since 3.0.0.14
 */
@property (nonatomic,copy) NSArray* speechActivity;


/**
 * Array of active speakers within scope. The array contains identifiers of users who are active speakers.
 *
 * @since 3.0.0.14
 */
@property (nonatomic,copy) NSArray* activeSpeakers;

@end // @interface ALSpeechActivityEvent:NSObject

/**
 * AddLive service listener protocol to receive global events from the
 * AddLive SDK.
 *
 * ### See Also:
 *
 * - `ALService`
 * - `[ALService addServiceListener:responder:]`
 * - `ALVideoFrameSizeChangedEvent`
 * - `ALConnectionLostEvent`
 * - `ALUserStateChangedEvent`
 * - `ALMediaStatsEvent`
 * - `ALMessageEvent`
 * - `ALMediaConnTypeChangedEvent`
 * - `ALMediaIssueEvent`
 * - `ALMediaInterruptEvent`
 */
@protocol ALServiceListener

// All the notifications are optional to have different listeners for
// different purposes
@optional

/**
 * Notifies about a change of a spatial resolution of a video feed produced by
 * given sink.
 *
 * This change may be caused by one of following:
 *
 * * Adaptation algorithms decided to increase or reduce the quality of the
 *   video feed on remote end uplink
 * * Remote peer reconfigured the video stream
 * * In case of screen sharing, the window shared was resized
 *
 * @see ALVideoFrameSizeChangedEvent
 * @param event ALVideoFrameSizeChangedEvent
 *        Event describing the change.
 * @since 1.0.0.0
 */
- (void) onVideoFrameSizeChanged:(ALVideoFrameSizeChangedEvent*) event;

/**
 * Notifies about a lost connection for a scope with given id.
 *
 * Connection may be lost due to one of following:
 *
 * - The device lost Internet connectivity,
 * - There was a failure of network equipment (e.g. router/Access Point),
 * - There was an error with the AddLive Streaming Server.
 *
 * @param event ALConnectionLostEvent
 *        Event describing the change.
 * @since 1.0.0.0
 */
- (void) onConnectionLost:(ALConnectionLostEvent*) event;

/**
 * Notifies about a reestablished connection to the addlive streaming server
 *
 * @param event ALConnectionLostEvent
 *        Event describing the change.
 * @since 3.0.0.0
 */
- (void) onSessionReconnected:(ALSessionReconnectedEvent*) event;

/**
 * Notifies about a change in connectivity status of a remote participant.
 *
 * From API perspective, this event will be triggered by a call on the
 * remote end to either `[ALService connect:responder:]` or
 * `[ALService disconnect:responder:]` methods.
 *
 * The `ALUserStateChangedEvent` passed to the callback has all the properties
 * defined except for the `[ALUserStateChangedEvent mediaType]` as the event is
 * not related to any particular media type. Please note that the
 * `[ALUserStateChangedEvent videoSinkId]` and
 * `[ALUserStateChangedEvent screenSinkId]` properties are defined
 * only if the `[ALUserStateChangedEvent videoPublished]` or
 * `[ALUserStateChangedEvent screenPublished]` is set to  `true`.
 * @param event ALUserStateChangedEvent
 *        Event describing the change.
 * @since 1.0.0.0
 * @see ALUserStateChangedEvent
 * @see [ALService connect:responder:]
 * @see [ALService disconnect:responder:]
 */
- (void) onUserEvent:(ALUserStateChangedEvent*) event;

/**
 * Notifies about media streaming status change for given remote user.
 *
 * Streaming status change may mean either that user started or stopped
 * publishing the stream of given media (audio, video, screen).
 *
 * From API perspective, this event will be triggered by a call on the
 * remote end to either `[ALService publish:what:options:responder:]` or
 * `[ALService unpublish:what:responder:]` methods.
 *
 * The `ALUserStateChangedEvent` passed to the callback has defined
 * only the attributes related to the media type. For example, if the event
 * is triggered by a remote peer publishing video, the
 * `ALUserStateChangedEvent` will have following attributes defined:
 *
 * - `[ALUserStateChangedEvent userId]`
 * - `[ALUserStateChangedEvent scopeId]`
 * - `[ALUserStateChangedEvent mediaType]` set to `[ALMediaType kVideo]`
 * - `[ALUserStateChangedEvent videoPublished]` set to `true`
 * - `[ALUserStateChangedEvent videoSinkId]`
 *
 * In general, the `ALUserStateChangedEvent` used in context of the
 * mediaStream callback method describes only the delta of the streaming state.
 * It's an application responsibility to store the state of remote peers
 * streaming, if required.
 *
 * @param event ALUserStateChangedEvent
 *        Event describing the change.
 * @since 1.0.0.0
 * @see [ALService publish:what:options:responder:]
 * @see [ALService unpublish:what:responder:]
 * @see ALUserStateChangedEvent
 */
- (void) onMediaStreamEvent:(ALUserStateChangedEvent*) event;

/**
 * Reports the availability of new media stream statistics.
 *
 * This needs to be actived with
 * [ALService startMeasuringStats:interval:responder:].
 *
 * @param event ALMediaStatsEvent
 *        Event describing the change.
 * @since 1.0.0.0
 * @see [ALService startMeasuringStats:interval:responder:]
 * @see [ALService stopMeasuringStats:responder:]
 * @see ALMediaStatsEvent
 */
- (void) onMediaStats:(ALMediaStatsEvent*) event;

/**
 * Reports a new message received from a remote peer.
 *
 * This callback will be triggered by a remote peer calling the
 * `[ALService sendMessage:message:recipientId:responder:]` method.
 *
 * @param event ALMessageEvent
 *        Event describing the change.
 * @since 1.0.0.0
 * @see [ALService sendMessage:message:recipientId:responder:]
 * @see ALMessageEvent
 */
- (void) onMessage:(ALMessageEvent*) event;

/**
 * Informs about a change in the media connection type.
 *
 * In most cases, this callback will be called directly after the connection
 * establishement, and then during the connection, when the amount of peers
 * connected changes from two to more and vice-versa. In this case the
 * connection type toggles between `[ALConnectionType kUdpRelayed]` and
 * `[ALConnectionType kUdpP2P]`.
 *
 * @param event ALMediaConnTypeChangedEvent
 *        Event describing the change.
 * @since 1.0.0.0
 * @see ALMediaConnTypeChangedEvent
 */
- (void) onMediaConnTypeChanged:(ALMediaConnTypeChangedEvent*) event;

/**
 * Informs about a change of media quality issue state.
 *
 * @param event ALMediaIssueEvent
 *        Event describing the change.
 * @since 1.0.0.0
 * @see ALMediaIssueEvent
 */
- (void) onMediaIssue:(ALMediaIssueEvent*) event;

/**
 * Method will be called when media was interrupted.
 *
 * #### Deprecated
 * Since 3.0.1.30 The AddLive SDK handles audio interruptions automatically.
 *
 * @param event ALMediaInterruptEvent
 *        Event describing the change.
 * @since 1.0.0.0
 * @see ALMediaInterruptEvent
 */
- (void) onMediaInterrupt:(ALMediaInterruptEvent*) event;


/**
 * Method will be called when there was a change in hardware devices configuration
 * (e.g. new USB camera plugged in)
 *
 * @param event ALMediaInterruptEvent
 *        Event describing the change.
 * @since 3.0.0.0
 */
- (void) onDeviceListChanged:(ALDeviceListChangedEvent*) event;

/**
 * Method will be called repeatedly with the local user speech level,
 * while the mic activity monitoring is enabled.
 *
 * @param event ALMediaInterruptEvent
 *        Event describing the change.
 * @since 3.0.0.0
 */
- (void) onMicActivity:(ALMicActivityEvent*) event;

/**
 * Method will be called when one of the media streams published by local user fails.
 *
 * This can be caused e.g. by a closing of a window that is currently shared by the user.
 *
 * @param event ALMediaStreamFailureEvent
 *        Event describing the change.
 * @since 3.0.0.0
 */
- (void) onMediaStreamFailure:(ALMediaStreamFailureEvent*) event;

/**
 * Method will be called to report the speech activivity within a particular session.
 *
 *
 * @param event ALSpeechActivityEvent
 *        Event describing the speech activity.
 * @since 3.0.0.14
 */
- (void) onSpeechActivity:(ALSpeechActivityEvent*) event;



@end // @protocol ALServiceListener
